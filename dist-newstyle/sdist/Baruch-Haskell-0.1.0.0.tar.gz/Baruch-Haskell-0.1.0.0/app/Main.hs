{-# LANGUAGE OverloadedStrings #-}

import Database.SQLite.Simple
import Control.Monad
import Conexion
import Crear
import Leer
import Actualizar
import Eliminar

main :: IO ()
main = do
    conn <- conectar "venta_pasajes.db"
    menuPrincipal conn
    close conn

menuPrincipal :: Connection -> IO ()
menuPrincipal conn = do
    putStrLn "1. Crear cliente"
    putStrLn "2. Leer clientes"
    putStrLn "3. Actualizar cliente"
    putStrLn "4. Eliminar cliente"
    putStrLn "5. Salir"
    putStrLn "Selecciona una opción:"
    opcion <- getLine
    case opcion of
        "1" -> crearCliente conn
        "2" -> leerClientes conn
        "3" -> actualizarCliente conn
        "4" -> eliminarCliente conn
        "5" -> putStrLn "Adiós!"
        _   -> putStrLn "Opción no válida" >> menuPrincipal conn
